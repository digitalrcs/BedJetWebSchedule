Boitier pour carte ESP32-S3-N16R8 by etmay53 on Thingiverse: https://www.thingiverse.com/thing:7165913

Summary:
Petit boitier pouvant recevoir une carte ESP32-S3-N16R8 afin de la protéger